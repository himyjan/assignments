# Week 0 Part 4

## Assignment

### Step 1: Complete Product Category Feature

Complete pages for different product categories.

Connect to [Product List API](https://github.com/AppWorks-School-Materials/API-Doc/blob/master/Stylish/README.md#product-list-api) by AJAX for data of all products, right after HTML DOM ready.

### Step 2: Complete Search Feature

Connect to [Product Search API](https://github.com/AppWorks-School-Materials/API-Doc/blob/master/Stylish/README.md#product-search-api) to build search feature for our customers.
