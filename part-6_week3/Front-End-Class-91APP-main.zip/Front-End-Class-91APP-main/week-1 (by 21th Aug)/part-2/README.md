# Week 1 Part 2

## Assignment

### Step 1: Complete Cart Page Layout

Complete cart page layout with RWD.  
Refer to [Figma](https://www.figma.com/file/sKhc4A0Gi427u1I5leT5ug/STYLiSH?node-id=80%3A122) for page design.
