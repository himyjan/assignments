# Week 1 Part 3

## Assignment

### Step 1: Handle Items in Cart Page

1. List items in the shopping cart.
2. Provide `modify quantity` and `remove item` features.
3. Calculate subtotal, freight, and total price based on the selection.

### Step 2: Validate User Input

In the cart page, let user write information.

1. Let user choose shipping and payment preference.
2. Let user fill the recipient information including name, email, phone, address, and time.
