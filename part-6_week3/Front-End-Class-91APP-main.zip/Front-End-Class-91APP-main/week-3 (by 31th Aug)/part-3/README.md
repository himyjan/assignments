# Week 3 Part 2

## Assignment

### Step 1: Complete Form Section of Checkout Page 
