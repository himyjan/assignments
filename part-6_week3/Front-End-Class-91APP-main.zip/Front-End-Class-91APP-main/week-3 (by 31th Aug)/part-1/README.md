# Week 3 Part 1

## Assignment

### Step 1: Complete Product Page 
