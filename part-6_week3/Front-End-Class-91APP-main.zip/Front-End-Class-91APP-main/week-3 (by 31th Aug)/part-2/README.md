# Week 3 Part 2

## Assignment

### Step 1: Complete Cart Section of Checkout Page 
