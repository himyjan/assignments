# Week 2 Part 4

## Assignment

### Step 1: Complete Carousel Section of Home Page 
