# Week 2 Part 3

## Assignment

### Step 1: Create React App

### Step 2: Deploy to Firebase Hosting

### Step 3: Complete Home Page Layout with Styled-Components
