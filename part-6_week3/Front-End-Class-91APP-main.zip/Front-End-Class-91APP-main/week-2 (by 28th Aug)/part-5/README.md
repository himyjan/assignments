# Week 2 Part 5

## Assignment

### Step 1: Complete Products Section of Home Page 
